// *****  The values MAX_TERMS, MAX_PPT and MAX_PARAM must agree in three files !!  *****
// *****  The three files: mfit.F90, mfit_cparams.h and mfit__define.pro            *****
// *****  VERSION_LEN must agree in two of the files !!                             *****

#define MAX_TERMS 55
#define MAX_PPT   10
#define MAX_PARAM 20
#define VERSION_LEN 40
